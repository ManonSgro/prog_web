// dropdown
/*var $ = jQuery.noConflict();
	$(function() {
		$('#activator').click(function(){
			$('#box').animate({'top':'0px'},900);
		});
		$('#boxclose').click(function(){
		$('#box').animate({'top':'-1000px'},900);
		});
	});	*/			

